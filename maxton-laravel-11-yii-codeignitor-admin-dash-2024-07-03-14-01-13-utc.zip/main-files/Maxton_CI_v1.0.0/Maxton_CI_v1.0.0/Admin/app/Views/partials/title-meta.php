<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= ($title) ? $title : '' ?> | Codeigniter & Bootstrap 5 Admin Dashboard Template</title>
<!--favicon-->
<link rel="icon" href="assets/images/favicon-32x32.png" type="image/png">